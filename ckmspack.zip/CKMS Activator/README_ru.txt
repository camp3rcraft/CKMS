[===CKMS Activator===]
by camper_crafting

GitHub: https://github.com/camp3rcraft/CKMS-Activator

Запускать файл "main.bat" в этой же папке
Обязательно с правами администратора.

Какие издания Windows есть?
- Home
- Pro
- Education
(Работает с Windows 10 & Windows 11)

Доп. функционал:
- Удаление уже установленного ключа активации
- Просмотр ченджлога

Последнее обновление: 21.08.2024